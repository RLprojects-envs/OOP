//Billaudaz-Nabet Yann
//3104949
//03/10/2022
public class Laptop {
	private String makeOfLaptope;
	private String processorType;
	private int rAM;
	private int hardDrive;
	private int price;
	
	//Constructor
	public Laptop(String makeOfLaptope, String processorType, int rAM, int hardDrive, int price) {
		this.makeOfLaptope = makeOfLaptope;
		this.processorType = processorType;
		this.rAM = rAM;
		this.hardDrive = hardDrive;
		this.price = price;
	}

	public String toString() {
		return "Make: " + makeOfLaptope + ", Processor: " + processorType + ", RAM: " + rAM
				+ "GB, Hard Drive: " + hardDrive + "GB, Price: " + price + "�";
	}

	public int getRAM() {
		return rAM;
	}
	
	public void adjustPrice(int adjustement) {
		this.price = this.price + adjustement;
	}
	
}
