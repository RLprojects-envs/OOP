//Billaudaz-Nabet Yann
//3104949
//03/10/2022
public class LogicGate {
	
	private boolean state;

	//Constructor
	public LogicGate(boolean state) {
		this.state = state;
	}

	public void not() {
		state = !state;
	}
	
	public String state() {
		if (state) {
			return "on";
		} else {
			return "off";
		}
	}
	
	public void set() {
		state=true;
	}
	
	public void negate() {
		state=false;
	}

}
