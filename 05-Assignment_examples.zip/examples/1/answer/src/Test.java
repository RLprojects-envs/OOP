//Billaudaz-Nabet Yann
//3104949
//03/10/2022
public class Test {

	public static void main(String[] args) {
		//Creation of two laptops
		Laptop first = new Laptop("ACER", "Intel core i5", 4, 1000, 600);
		Laptop second = new Laptop("DELL", "Intel core i7", 8, 1500, 1100);
		//Write the informations of these laptops
		System.out.println(first.toString());
		System.out.println(second.toString());
		//Check which laptop has the biggest RAM and decrease the price by 100� of the one who has the lowest RAM
		if (first.getRAM()>second.getRAM()) {
			System.out.println("Laptop one has more RAM.");
			second.adjustPrice(-100);
		} else if (first.getRAM()<second.getRAM()) {
			System.out.println("Laptop two has more RAM.");
			first.adjustPrice(-100);
		} else {
			//if the two laptops have the same RAM, the price is decreased by 100� for both of them
			System.out.println("Laptop one and two have the same RAM.");
			first.adjustPrice(-100);
			second.adjustPrice(-100);
		}
		//Write the informations of the laptops after the decrease of the price
		System.out.println(first.toString());
		System.out.println(second.toString());
		
		
		//Creation of a Logic Gate
		LogicGate gate = new LogicGate(false);
		//Write the state of the Gate
		System.out.println("\nThe gate is "+ gate.state());
		//Change the state of the gate to its opposite and write the new state of the Gate
		gate.not();
		System.out.println("After not the gate is "+ gate.state());
		//Change the state of the gate to on and write the new state of the Gate
		gate.set();
		System.out.println("After set the gate is "+ gate.state());
		//Change the state of the gate to off and write the new state of the Gate
		gate.negate();
		System.out.println("After negate the gate is "+ gate.state());
		
		
	}

}
