package assignment3;
/* Manon GOFFINET - 3107597 - 18/10/2022 */
/*Class: TicketManager
*
* Student Name: Manon GOFFINET  
* Student Number: 3107597 
*
*/

import java.util.Random;

class TicketManager{
	private Ticket[] tickets;
	private int sold = 0;
	private int maxTickets = 500;

	/*Constructor*/
	TicketManager(){
		tickets = new Ticket [maxTickets];
	}
	
	
	/* Method boolean buy(Ticket t)
	 * Add the ticket to the next available slot in the list on condition that the number sold does not exceed maxTickets. 
	 * It returns true if successful, false otherwise. */
	public boolean buy(Ticket t)
	{
		
		boolean canBuy = false;
		if (sold<maxTickets) {
			canBuy = true;
			tickets[sold]=t;
			sold++;
		}
		return canBuy;

	}
	
	
	/* Method boolean buy()
	 * Generate and add the ticket to the next available slot in the list on condition that the number sold does not exceed maxTickets. 
	 * It randomly select the numbers and generate the ticket
	 * It returns true if successful, false otherwise */
	public boolean buy(){
		boolean canBuy = false;
		if (sold<maxTickets) 
		{
			canBuy =true;
			Random r = new Random();
			/* java.util.Random.nextInt(int i) : 
			 * generates a random number between 0(inclusive) and the number passed in this argument(n), exclusive.*/
			int a = r.nextInt(5); 
			int b = r.nextInt(5);
			
			Ticket t = new Ticket(a,b);
			tickets[sold]=t;
			sold++;
		}
		return canBuy;
	}

	
	/* Method int freqWinner(Ticket t)
	 * Count how many tickets match the winning ticket and return the number */
	public int freqWinner(Ticket t){
		int winCount=0;
		for(int i =0; i<sold;i++) {
			if(tickets[i].a()==t.a() && tickets[i].b()==t.b()) 
			{
				winCount++;
			}
		}
		return winCount;
	}

	
	/* Method Ticket[] getWinners(Ticket t)
	 * Return a list of all tickets that match the winning ticket drawn */
	public Ticket[] getWinners(Ticket t){
		int nOfWinners = freqWinner(t);
		Ticket [] winner = new Ticket [nOfWinners];
		int winnerCount =0;
		int i =0;
		while(i<sold && winnerCount<nOfWinners) 
		{
			if(tickets[i].a()==t.a() && tickets[i].b()==t.b()) 
			{
				winner[winnerCount]=tickets[i];
				winnerCount++;
			}
			i++;
		}
		return winner;
		
	}

	/* Method boolean search(Ticket t)
	 * Searches for the given ticket and returns true if found; false otherwise */
	public boolean search(Ticket t){
		boolean found = false;
		int i =0;
		while(i<sold&&!found) 
		{
			if(tickets[i].a()==t.a() && tickets[i].b()==t.b()) 
			{
				found=true;
			}
			i++;
		}
		return found;
	}

	/* Method int sold()
	 * Returns the number of tickets sold */
	public int sold(){
		return sold;
	}

	/* Method boolean allsold()
	 * Returns true if all tickets are sold; false otherwise */
	public boolean allsold(){
		
		return sold==maxTickets;
	}

	//do not edit
	public String toString(){
		if(sold == 0)
			return "[]";

		String s = "[";
		for(int j = 0; j < sold - 1; j++) {
			s = s + tickets[j] + ",";
		}
		return s+tickets[sold-1]+"]";
	}
}