package assignment3;
/*
 * Class: Ticket
 *
 * DO NOT EDIT ANYONE CODE IN THIS FILE
 */

class Ticket{
	private final int a, b;

	Ticket(int a, int b){
		this.a = a;
		this.b = b;
	}

	public int a(){
		return a;
	}

	public int b(){
		return b;
	}

	public String toString(){
		return "["+a+","+b+"]";
	}
}
