/* Manon GOFFINET - 3107597 - 18/10/2022 */
package assignment3;
/*
 * Class: Assignment3
 *
 * Test class for Assignment 3 
 *
 */


public class Assignment3{
	public static void main(String args[]){


		// Q1  ==============================================
		// This code is a sample test for Q2. You will need to add more tests to test all methods
		
		/*test of Constructor*/
		TicketManager tm = new TicketManager();
     	System.out.println("Empty Ticket Manager : " + tm);
     	
     	/*test of TicketManager.buy(Ticket t)*/
     	Ticket t1 = new Ticket((int)(Math.random()*5),(int)(Math.random()*5));
     	tm.buy(t1);
     	System.out.println("Ticket Manager with one ticket : " +tm);
     	Ticket t2 = new Ticket((int)(Math.random()*5),(int)(Math.random()*5));
     	boolean ticketSold = tm.buy(t2);
     	System.out.println("the ticket have been sold: "+ticketSold);
     	System.out.println("Ticket Manager with two ticket : "+ tm);
     	
     	
     	/*test of TicketManager.buy()*/
     	for(int j = 0; j < 20; j++) {
     		ticketSold = tm.buy();
     	}
     	System.out.println("the ticket have been sold: "+ticketSold);
     	
     	/*test of TicketManager.search(Ticket t)*/
     	Ticket random = new Ticket((int)(Math.random()*5),(int)(Math.random()*5));
     	System.out.println("\nthe ticket "+random+" is inside the Ticket Manager: "+tm.search(random));
     	
     	/*test of TicketManager.sold()*/
     	System.out.println("the number of tickets sold: "+tm.sold());
     	
     	
     	/*test of TicketManager.allsold()*/
     	System.out.println("all the tickets are sold: "+tm.allsold());
     	int i =0;
     	while(i < 500&&ticketSold) // test of the tm.buy() stop function in case of too many tickets 
     	{
     		ticketSold = tm.buy();
     		if(!ticketSold) {
     			int a = i-1;
     			System.out.println("The precedent ticket was the "+ tm.sold()+" in the Ticket Manager so the ticket "+i+" of the loop couldn't be sold as the ticket manager is full.");
     		}
     		i++;
     	}
     	System.out.println("all the tickets are sold: "+tm.allsold());
     	
     	
     	
     	/*test of TicketManager.freqWinner(Ticket draw)*/
     	Ticket draw = new Ticket((int)(Math.random()*5),(int)(Math.random()*5));//winning ticket
     	System.out.println("\nthe winning ticket is: "+draw);
     	System.out.println("Number of winning tickets in Ticket Manager : "+tm.freqWinner(draw));
     	
     	/*test of TicketManager.getWinner(Ticket draw)*/
     	System.out.println("the winning ticket list: ");
     	for(int a = 0; a<tm.freqWinner(draw);a++) {
     		System.out.print(tm.getWinners(draw)[a]+", ");
     	}
     	
     	
     	
		
	}
}