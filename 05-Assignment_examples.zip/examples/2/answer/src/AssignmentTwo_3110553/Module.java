package AssignmentTwo_3110553;
//Oscar PASTURAL
//studID : 3110553
//Date : 10/10/2022
public class Module {
	private String moduleCode;
	private String moduleName;
	private String[] lecturers;
	private double moduleHours;
	private String moduleDescription;
	
	public Module()
	{
		this.moduleCode = "";
		this.moduleName = "Unassigned";
		this.lecturers = null;
		this.moduleHours = 0;
		this.moduleDescription = "empty"; //I created the empty constructor this way so no matter how we initialize it, it doesn't create errors using its methods.
	}
	public Module(String moduleCode, String moduleName, String[] lecturers, double moduleHours, String moduleDescription)
	{
		this.moduleCode = moduleCode;
		this.moduleName = moduleName;
		this.lecturers = lecturers;
		this.moduleHours = moduleHours;
		this.moduleDescription = moduleDescription;
	}
	public String getModuleCode() {
		return moduleCode;
	}
	public void setModuleCode(String newCode) {
		moduleCode=newCode;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String newName) {
		moduleName=newName;
	}
	
	public String[] getLecturers() {
		return lecturers;
	}
	public void setLecturers(String[] newLecturers) {
		lecturers=newLecturers;
	}
	public double getHours() {
		return moduleHours;
	}
	public void setHours(double newhours) {
		moduleHours=newhours;
	}
	public String getDesc() {
		return moduleDescription;
	}
	public void setDesc(String newdesc) {
		moduleDescription=newdesc;
	}
}
