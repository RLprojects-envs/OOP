package AssignmentTwo_3110553;
//Oscar PASTURAL
//studID : 3110553
//Date : 10/10/2022
public class Email {
	private String home; // records the home e-mail address
	private String work; //records the work e-mail.
	
	public Email() {
		this.home="";
		this.work="";
	}
	public Email(String home, String work) {
		this.home=home;
		this.work=work;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String newwork) {
		work = newwork;
	}
	public String getHome() {
		return home;
	}
	public void setHome(String newhome) {
		work = newhome;
	}
	

}
