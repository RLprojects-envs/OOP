package AssignmentTwo_3110553;
//Oscar PASTURAL
//studID : 3110553
//Date : 10/10/2022
public class Test {
	public static void main(String[] args) {
		PartOne(); //will play the first Part
		PartTwo(); //will play the part two
	}
	public static void PartOne() {
		Email jackmail = new Email("jackdaltonigoo@outlook.com","jackdalton@gmail.com");
		Employee jack = new Employee("Jack","Dalton",jackmail);
		System.out.println(jack.fullName() + "'s home address is " + jackmail.getHome() + " and work address is " + jackmail.getWork());/*getting both mails */
		System.out.println(jack.fullName() + "'s home address is " + jack.homeEmail());
		System.out.println(jack.fullName() + "'s work address is " + jack.workEmail() + "\n\n");
	}
	public static void PartTwo() {
		//We have a lot of initializing to do...
		String[] lecturersRD = new String[] {"Nelly Houston","James Daniel","Harry Ford"};
		Module relationalDatabase = new Module("BSCH-RD", "Relational Databases", lecturersRD,  25, "We will learn Chen's model");
		String[] lecturersOOP = new String[] {"Gary Bary","Sia Kelder","Jamy Fish"};
		Module oop = new Module("BSCH-OOP","Oriented Objects Programmation", lecturersOOP, 20, "Here we learn about objects and classes");
		String[] lecturersMaths = new String[] {"Ferdinand Einstein", "Henri Lavoisier","Johnny Styles"};
		Module probability = new Module("BSCH-PB","Maths-Probability",lecturersMaths,24,"A way to master the ancien art of maths...");
		
		Module[] jackModules = new Module[] {oop, probability};
		Module[] martinModules = new Module[] {relationalDatabase,oop};
		
		Student jack = new Student("Jack", "8 Oliver Street", "3110543", "ComputingScience", 2, jackModules);
		Student martin = new Student("Martin","10 Cliver Road", "3009876","ComputingScience",2,martinModules);
		Student[] allStudents = new Student[] {jack,martin};
		//we are looking with this foreach loop to optimize and not repeat the whole process to describe a student.
		//Since it's asked here to write in the test loop, I do not want to complicate things.
		//Normally, I'd create a getStudentInfo() method in the student class.
		
		for(Student s:allStudents) { 
			System.out.println("Student : " + s.getName() + ", " + s.getHomeAddress() + ", " + s.getId() + ", " + s.getDegreeProgram() + ", year " + s.getYear() + "\nEnrolled in :\n");
			for(Module i:jackModules) {
				System.out.println(i.getModuleCode() + "," + i.getModuleName() + "," + i.getHours() + "," + i.getDesc());
				System.out.println("Taught by : ");
				for(String y:i.getLecturers()) {
					System.out.print(y + ", ");
				}
				System.out.println("\n-----\n");
			}
			System.out.println("\n\n");
		}
		
	}
}
