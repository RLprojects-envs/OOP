package AssignmentTwo_3110553;
//Oscar PASTURAL
//studID : 3110553
//Date : 10/10/2022
public class Employee {
	private  String surname;
	private  String  firstName;
	private  Email emailAddress;
	
	public Employee(String surname, String  firstName, Email emailAddress) {
		this.surname=surname;
		this.firstName=firstName;
		this.emailAddress=emailAddress;
	}
	
	public String fullName() {
		String fullname = firstName + " " + surname;
		return fullname;
	}
	public Email getEmails() {
		return emailAddress;
	}
	public String workEmail() {
		return emailAddress.getWork();
	}
	public String homeEmail() {
		return emailAddress.getHome();
	}
	

}
