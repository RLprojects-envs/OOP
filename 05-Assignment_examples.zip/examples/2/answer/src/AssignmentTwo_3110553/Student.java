package AssignmentTwo_3110553;
//Oscar PASTURAL
//studID : 3110553
//Date : 10/10/2022
public class Student {
	private String name;
	private String homeAddress;
	private String id;
	private String degreeProgram;
	private int year;
	private Module[] modules;
	
	public Student()
	{
		this.name="Unknown";
		this.homeAddress="Unknown";
		this.id="";
		this.degreeProgram="";
		this.year=0;
		this.modules=null; //I created the empty constructor this way so no matter how we initialize it, it doesn't create errors using its methods.
	}
	public Student(String name, String homeAddress, String id, String degreeProgram, int year, Module[] modules) {
		this.name=name;
		this.homeAddress=homeAddress;
		this.id=id;
		this.degreeProgram=degreeProgram;
		this.year=year;
		this.modules=modules;
	}
	//all the setters and getters
	public String getName() {
		return name;
	}
	public void setName(String newname) {
		name=newname;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String newaddress) {
		homeAddress=newaddress;
	}
	public String getId() {
		return id;
	}
	public void setId(String newId) {
		id=newId;
	}
	public String getDegreeProgram() {
		return degreeProgram;
	}
	public void setDegreeProgram(String newDegProg) {
		degreeProgram=newDegProg;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int newYear) {
		year=newYear;
	}
	public Module[] getModules() {
		return modules;
	}
	public void setModules(Module[] newmodules) {
		modules=newmodules;
	}
}
