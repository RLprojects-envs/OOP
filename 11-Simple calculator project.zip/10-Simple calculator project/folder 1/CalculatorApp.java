import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.math.BigInteger;

public class CalculatorApp {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Calculator App");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(2, 3));

        // Create and add the Combination with Replacement Calculator
        JPanel combinationPanel = createCombinationPanel();
        frame.add(combinationPanel);

        // Create and add the Factorial Calculator
        JPanel factorialPanel = createFactorialPanel();
        frame.add(factorialPanel);

        // Create and add the Fibonacci Calculator
        JPanel fibonacciPanel = createFibonacciPanel();
        frame.add(fibonacciPanel);

        // Create and add the Multifactorial Calculator
        JPanel multifactorialPanel = createMultifactorialPanel();
        frame.add(multifactorialPanel);

        // Create and add the Pascal's Triangle Calculator
        JPanel pascalPanel = createPascalPanel();
        frame.add(pascalPanel);

        // Create and add the Nth Prime Calculator
        JPanel primePanel = createPrimePanel();
        frame.add(primePanel);

        frame.setVisible(true);
    }

    private static JPanel createCombinationPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        final JTextField nField = new JTextField(5);
        final JTextField kField = new JTextField(5);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(nField.getText());
                    int k = Integer.parseInt(kField.getText());
                    BigInteger combinations = CombinationWithReplacementCalculator.calculateCombinationWithReplacement(n, k);
                    resultLabel.setText("Result: " + combinations.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("Combination with Replacement Calculator"), BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("n: "));
        inputPanel.add(nField);
        inputPanel.add(new JLabel("k: "));
        inputPanel.add(kField);
        inputPanel.add(calculateButton);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(resultLabel, BorderLayout.SOUTH);

        return panel;
    }

    private static JPanel createFactorialPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    BigInteger factorial = FactorialCalculator.calculateFactorial(n);
                    resultLabel.setText("Result: " + factorial.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("Factorial Calculator"), BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.add(inputField);
        inputPanel.add(calculateButton);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(resultLabel, BorderLayout.SOUTH);

        return panel;
    }

    private static JPanel createFibonacciPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    BigInteger fibonacci = FibonacciCalculator.calculateFibonacci(n);
                    resultLabel.setText("Result: " + fibonacci.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("Fibonacci Calculator"), BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.add(inputField);
        inputPanel.add(calculateButton);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(resultLabel, BorderLayout.SOUTH);

        return panel;
    }

    private static JPanel createMultifactorialPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    BigInteger multifactorial = MultifactorialCalculator.calculateMultifactorial(n);
                    resultLabel.setText("Result: " + multifactorial.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("Multifactorial Calculator"), BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.add(inputField);
        inputPanel.add(calculateButton);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(resultLabel, BorderLayout.SOUTH);

        return panel;
    }

    private static JPanel createPascalPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        final JTextField nField = new JTextField(5);
        final JTextField kField = new JTextField(5);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(nField.getText());
                    int k = Integer.parseInt(kField.getText());
                    BigInteger coefficient = PascalCalculator.calculateBinomialCoefficient(n, k);
                    resultLabel.setText("Result: " + coefficient.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("Pascal's Triangle Calculator"), BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("n: "));
        inputPanel.add(nField);
        inputPanel.add(new JLabel("k: "));
        inputPanel.add(kField);
        inputPanel.add(calculateButton);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(resultLabel, BorderLayout.SOUTH);

        return panel;
    }

    private static JPanel createPrimePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    long nthPrime = PrimeCalculator.calculateNthPrime(n);
                    resultLabel.setText("Result: " + nthPrime);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("Nth Prime Calculator"), BorderLayout.NORTH);
        JPanel inputPanel = new JPanel();
        inputPanel.add(inputField);
        inputPanel.add(calculateButton);
        panel.add(inputPanel, BorderLayout.CENTER);
        panel.add(resultLabel, BorderLayout.SOUTH);

        return panel;
    }
}
