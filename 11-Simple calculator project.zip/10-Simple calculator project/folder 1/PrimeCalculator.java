import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PrimeCalculator {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Nth Prime Calculator");
        frame.setSize(400, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    long nthPrime = calculateNthPrime(n);
                    resultLabel.setText("Result: " + nthPrime);
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(inputField);
        panel.add(calculateButton);
        panel.add(resultLabel);

        frame.setVisible(true);
    }

    public static long calculateNthPrime(int n) {
        if (n <= 0) {
            return -1; // Invalid input
        }

        int count = 0;
        long num = 2;
        while (true) {
            if (isPrime(num)) {
                count++;
                if (count == n) {
                    return num;
                }
            }
            num++;
        }
    }

    public static boolean isPrime(long num) {
        if (num <= 1) {
            return false;
        }
        for (long i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
