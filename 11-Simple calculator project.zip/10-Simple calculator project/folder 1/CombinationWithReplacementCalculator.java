import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.math.BigInteger;

public class CombinationWithReplacementCalculator {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Combination with Replacement Calculator");
        frame.setSize(400, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);

        final JTextField nField = new JTextField(5);
        final JTextField kField = new JTextField(5);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(nField.getText());
                    int k = Integer.parseInt(kField.getText());
                    BigInteger combinations = calculateCombinationWithReplacement(n, k);
                    resultLabel.setText("Result: " + combinations.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("n: "));
        panel.add(nField);
        panel.add(new JLabel("k: "));
        panel.add(kField);
        panel.add(calculateButton);
        panel.add(resultLabel);

        frame.setVisible(true);
    }

    public static BigInteger calculateCombinationWithReplacement(int n, int k) {
        if (n < 0 || k < 0) {
            return BigInteger.ZERO; // Invalid input
        }

        // Calculate (n + k - 1) choose k
        BigInteger numerator = factorial(n + k - 1);
        BigInteger denominator = factorial(k).multiply(factorial(n - 1));
        return numerator.divide(denominator);
    }

    public static BigInteger factorial(int n) {
        if (n < 0) {
            return BigInteger.ZERO;
        }
        BigInteger result = BigInteger.ONE;
        for (int i = 2; i <= n; i++) {
            result = result.multiply(BigInteger.valueOf(i));
        }
        return result;
    }
}
