import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.math.BigInteger;

public class MultifactorialCalculator {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Multifactorial Calculator");
        frame.setSize(400, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    BigInteger multifactorial = calculateMultifactorial(n);
                    resultLabel.setText("Result: " + multifactorial.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(inputField);
        panel.add(calculateButton);
        panel.add(resultLabel);

        frame.setVisible(true);
    }

    public static BigInteger calculateMultifactorial(int n) {
        if (n < 0) {
            return BigInteger.valueOf(-1); // Invalid input
        }

        BigInteger result = BigInteger.ONE;
        int step = (n % 2 == 0) ? 2 : 1; // Start with 2 for even n, 1 for odd n
        for (int i = n; i >= 1; i -= step) {
            result = result.multiply(BigInteger.valueOf(i));
        }
        return result;
    }
}
