import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.math.BigInteger;

public class PascalCalculator {

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pascal's Triangle Calculator");
        frame.setSize(400, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);

        final JTextField nField = new JTextField(5);
        final JTextField kField = new JTextField(5);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(nField.getText());
                    int k = Integer.parseInt(kField.getText());
                    BigInteger coefficient = calculateBinomialCoefficient(n, k);
                    resultLabel.setText("Result: " + coefficient.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(new JLabel("n: "));
        panel.add(nField);
        panel.add(new JLabel("k: "));
        panel.add(kField);
        panel.add(calculateButton);
        panel.add(resultLabel);

        frame.setVisible(true);
    }

    public static BigInteger calculateBinomialCoefficient(int n, int k) {
        if (n < 0 || k < 0 || k > n) {
            return BigInteger.ZERO; // Invalid input
        }

        BigInteger[][] dp = new BigInteger[n + 1][k + 1];

        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= Math.min(i, k); j++) {
                if (j == 0 || j == i) {
                    dp[i][j] = BigInteger.ONE;
                } else {
                    dp[i][j] = dp[i - 1][j - 1].add(dp[i - 1][j]);
                }
            }
        }

        return dp[n][k];
    }
}
