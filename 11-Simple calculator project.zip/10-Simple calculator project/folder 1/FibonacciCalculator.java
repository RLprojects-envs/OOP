import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

public class FibonacciCalculator {

    private static Map<Integer, BigInteger> memo = new HashMap<>();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Fibonacci Calculator");
        frame.setSize(400, 150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);

        final JTextField inputField = new JTextField(10);
        final JLabel resultLabel = new JLabel("Result: ");
        JButton calculateButton = new JButton("Calculate");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(inputField.getText());
                    BigInteger fibonacci = calculateFibonacci(n);
                    resultLabel.setText("Result: " + fibonacci.toString());
                } catch (NumberFormatException ex) {
                    resultLabel.setText("Invalid input");
                }
            }
        });

        panel.add(inputField);
        panel.add(calculateButton);
        panel.add(resultLabel);

        frame.setVisible(true);
    }

    public static BigInteger calculateFibonacci(int n) {
        if (n < 0) {
            return BigInteger.valueOf(-1); // Invalid input
        }

        if (n <= 1) {
            return BigInteger.valueOf(n);
        }

        if (memo.containsKey(n)) {
            return memo.get(n);
        }

        BigInteger fib = calculateFibonacci(n - 1).add(calculateFibonacci(n - 2));
        memo.put(n, fib);
        return fib;
    }
}
