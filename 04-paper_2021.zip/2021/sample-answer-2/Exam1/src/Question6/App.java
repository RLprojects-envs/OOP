package Question6;

public class App {
    public static void main(String[] args) throws Exception {

        Widget w = new Widget();
        Widget w1 = new Widget();

        System.out.println(Widget.numberOfWidgets); //Since the variable is static, we can access it directly from the class

    }
    
}
