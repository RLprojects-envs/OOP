package Question6;

public class Widget {

    static int numberOfWidgets=0;

    public Widget() {
        numberOfWidgets++;
    }

    
    
}
