package Question10;

import java.util.HashSet;


class Library {
    private HashSet<Book> data = new HashSet<>();


    public void add(Book c) {
        data.add(c);
    }

    public boolean search(Book c){// search for Book c
        if(data.contains(c)) {
            return true;
        } else {
            return false;
        }
    }

    public Book get(String r){
    //return reference to first Book that has title equal to r
    for(Book b : data) {
        if(b.title()==r) {
            return b;
        }
    }

    System.out.println("Book not found");
    return null;
    } 
    

    public int count(){
        int count = 0;
        for(Book b:data) {
            count++;
        }

        return count;
    }

    
    public void addBooks(HashSet<Book> set){
            //add the collection of Books to data
            data.addAll(set);

            } 
     }
