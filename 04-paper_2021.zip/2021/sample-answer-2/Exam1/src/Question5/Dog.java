package Question5;

public class Dog {
    private String breed;
    private String name;
    private int age;

    public Dog(String b, String n, int a) {
        breed = b;
        name = n;
        age = a;
    }

    public String breed() {
        return breed;
    }

    public String name() {
        return name;
    }

    public int age() {
        return age;
    }

    public void setBreed(String val) {
        this.breed = val;
    }

    public void setName(String val){
        this.name = val;
    }

    public void setAge(int val) {
        this.age = val;
    }
}
