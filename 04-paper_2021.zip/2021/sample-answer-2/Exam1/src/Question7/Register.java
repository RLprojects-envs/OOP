package Question7;

class Register {
    private static Register reg = null;
    private String[] data;
    private int size;

    private Register() {
        this.data = new String[100];
        this.size = 0;
    }

    public static Register getRegister() {
        if(reg==null) {
            reg = new Register();        
        }
        return reg;
    }

    public boolean register(String name) {
        if(size<data.length && name.length()>0) {
            if(search(name)) {
                return false;
            } else {
                data[size] = name;
                size++;
                return true;
            }
        } else {
            return false;
        }
    }

    public int size() {
        return size;
    }

    public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    private boolean search(String n) {
        boolean found = false;
        for (int j = 0; j < size && !found; j++)
            if (data[j].equals(n))
                found = true;
        return found;
    }
}
