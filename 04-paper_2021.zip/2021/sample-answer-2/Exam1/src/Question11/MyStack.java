package Question11;
import java.util.LinkedList;

public class MyStack {
    private LinkedList<String> lst;
   

    MyStack() {
        lst = new LinkedList<>();
    }

    public void push(String x){ // add x to list lst  (2 marks)
        lst.add(x);
        
    }
    public String pop(){ // remove last added value from list lst  (2 marks)
        int i = lst.size();
        String removed = lst.get(i);
        lst.removeLast();
        return removed;
    }
    public String peek(){ // return but do not remove last added value from list lst  (2 marks)
        return lst.get(lst.size());
    }
    public boolean search(String x){ // Search stack for value x (3 marks)
        if(lst.contains(x)) {
            return true;
        } else {
            return false;
        }
    }
    public int size(){ //return number of elements in the stack  (1 mark)
        return lst.size();
    }
}
