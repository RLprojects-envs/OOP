package Question1;
public class App {
    public static void main(String[] args) throws Exception {

        String[] lm = {
            "Maths", "OOP"};
        Student stud = new Student("Laurent", lm, "Cork", "1" );

        System.out.println(stud.getName());
        System.out.println(stud.getId());
    }
}

