package Question1;
public class Student {

    private String name;
    private String[] list_of_modules;
    private String address;
    private String id;

    public Student(String n, String[] lm, String a, String i) {
        this.name = n;
        this.list_of_modules = lm;
        this.address = a;
        this.id = i;
    }


    public String getName() {
        return this.name;
    }

    public String[] getModules() {
        return this.list_of_modules;
    }

    public String getAddress() {
        return this.address;
    }

    public String getId() {
        return this.id;
    }

    public String toString() {
        return "Name :" + name +"\n" + "List of modules :" + getModules() +"\n"  + "Address :" + address + "\n" + "Id :" + id;
    }


}