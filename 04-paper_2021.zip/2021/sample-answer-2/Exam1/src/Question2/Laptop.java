package Question2;

class Laptop {
    private Battery battery;
    private String brand;

    public Laptop(Battery battery, String brand) {
        this.battery = new Battery(battery.getType(), battery.getVoltage());
        this.brand = brand;
    }

    public String getBatteryName() {
        return this.battery.getType();
    }

    public int getBatteryVoltage() {
        return this.battery.getVoltage();
    }

    public void setBatteryName(String val) {
        this.battery.setType(val);
    }

    public void setBatteryType(int val) {
        this.battery.setVoltage(val);
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String val) {
        this.brand = val;
    }

    


}