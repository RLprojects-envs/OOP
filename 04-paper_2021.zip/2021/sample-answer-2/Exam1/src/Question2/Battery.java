package Question2;

class Battery {
    private String type;
    private int voltage;

    public Battery(String type, int voltage) {
        this.type = type;
        this.voltage = voltage;
    }

    public String getType() {
        return type;
    }

    public int getVoltage() {
        return voltage;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setVoltage (int voltage)
     {
     this.voltage = voltage;
    }

}