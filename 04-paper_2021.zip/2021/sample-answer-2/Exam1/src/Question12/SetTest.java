package Question12;
import java.util.TreeSet;
import java.util.Arrays;


class SetTest {
    TreeSet<Integer> ts1 = new TreeSet<>(Arrays.asList(1, 2, 3, 4, 5));
    TreeSet<Integer> ts2 = new TreeSet<>(Arrays.asList(4, 5, 7, 8));

    //@Test
    public void testSubSet(){
        TreeSet<Integer> sub_set = new TreeSet<Integer>();
        sub_set = (TreeSet<Integer>)ts1.subSet(2, 5);
        for(Integer i : sub_set) {
            System.out.println(i);
        }
    }

    //@Test
    public void testDifference(){
        ts2.removeAll(ts1);
        System.out.println("Difference is " + ts2); 

    }
}

