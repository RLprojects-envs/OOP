package Question4;

public class Book extends Publication {
    private String author;
    private String isbn;

    public Book(String t, String p, String author, String isbn) {
        super(t, p);
        this.author = author;
        this.isbn = isbn;
    }
    
}
