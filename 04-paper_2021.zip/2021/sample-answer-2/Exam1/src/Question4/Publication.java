package Question4;

public class Publication {
    private String title;
    private String publisher;

    public Publication(String t, String p) {
        this.title = t;
        this.publisher = p;
    }
    
}
