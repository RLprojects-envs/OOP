package Question4;

public class LibraryBook extends Book {
    private int catalogue_number;
    private int copy_number;

    public LibraryBook(String t, String p, String a, String isbn, int cn, int cnu ) {
        super(t, p, a, isbn);
        this.catalogue_number = cn;
        this.copy_number = cnu;
    }
    
}
