package Question3;

class Car {
    private String make;
    private String model;
    private double price;

    public Car (String make, String model, double price) {
    this.make = make; this.model = model; this.price = price;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String toString(){return make+" "+ model+ "," +price;}

}
