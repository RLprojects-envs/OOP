package Question3;

public class App {

    public static void main(String[] args) throws Exception {

        Car[] myArray = {new Car ("Ford", "Mustang", 52000.00),
        new Car ("BMW", "i8", 55000.00),
        new Car ("Range Rover", "Evoque", 42000.00)};
        
        System.out.println(myArray);
        for(Car car : myArray) System.out.println(car +" " );
        for(int i=0; i< myArray.length; i++) {
        myArray [i].setMake("Honda");
        myArray [i].setModel("Accord");
        myArray [i].setPrice(35000.00);
        for(Car car: myArray) System.out.println(car +"");

    }

    

}

}
