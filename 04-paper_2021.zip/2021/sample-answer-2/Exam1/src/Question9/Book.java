package Question9;
import java.util.Date;

public class Book implements Comparable<Book> {
    private String author, title;
    private Date publishDate;

    Book(String s, String r, Date v) {
        author = s;
        title = r;
        publishDate = v;
    }

    public String author() {
        return author;
    }

    public String title() {
        return title;
    }

    public Date publishDate() {
        return publishDate;
    }

    public String toString() {
        return author + " " + title + " " + publishDate;
    }

    public boolean equals(Book b) {
        if(!(b instanceof Book)) {
            return false;
        }

        Book a = (Book) b;
        if(author==a.author && title==a.title) {
            return true;
        } else {
            return false;
        }
    }

    public int compareTo(Book b) {
        int result = this.author.compareTo(b.author);
        if(result==0) {
            result = this.title.compareTo(b.title);
        }

        return result;
    }

    public int hashCode() {
        String a = author + title;
        return a.hashCode();
    }
}