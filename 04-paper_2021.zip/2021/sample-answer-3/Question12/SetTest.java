package Question12;

/*
a) 

b)


 */

class SetTest {
	TreeSet<Integer> ts1 = new TreeSet<>(Arrays.asList(1, 2, 3, 4, 5));
	TreeSet<Integer> ts2 = new TreeSet<>(Arrays.asList(4, 5, 7, 8));

@Test
public void testSubSet(){ � }

@Test
public void testDifference(){ � }
}
