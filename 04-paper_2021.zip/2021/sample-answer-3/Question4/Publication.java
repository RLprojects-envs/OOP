package Question4;

class Publication {
	public String title;
	public String publisher;

public Publication(String title, String publisher) {
	this.title = title;
	this.publisher = publisher;
}
}

class Book extends Publication {
	public String author;
	public String ISBNNumber;
	
	public Book(String title, String publisher, String author, String ISBNNumber) {
		super(title, publisher);
		this.author = author;
		this.ISBNNumber = ISBNNumber;
	}
}

class LibraryBooks extends Book{
	public int catalogueNumber;
	public int copyNumber;
	
	public LibraryBooks(String title, String publisher, String author, String ISBNNumber, int catalogueNumber, int copyNumber) {
		super(title, publisher, author, ISBNNumber);
		this.catalogueNumber = catalogueNumber;
		this.copyNumber = copyNumber;
	}
}
