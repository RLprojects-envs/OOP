package Question10;

import java.util.HashSet;

class Library {
	private HashSet<Book> data = new HashSet<>();

	public void add(Book c) {
		data.add(c);
	}

public boolean search(Book c){
	// search for Book c
	}

public Book get(String r){
//return reference to first Book that has title equal to r
}

public int count(){
//Get the amount of books in Library
}

public void addBooks(HashSet<Book> set){
set.add(c);
}
}