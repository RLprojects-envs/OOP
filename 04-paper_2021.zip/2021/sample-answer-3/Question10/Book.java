package Question10;

import java.util.Date;

public class Book {
	private String author, title;
	private Date publishDate;

	Book(String s, String r, Date v) {
		author = s;
		title = r;
		publishDate = v;
	}

	public String author() {
		return author;
	}

	public String title() {
		return title;
	}

	public Date publishDate() {
		return publishDate;
	}

	public String toString() {
		return author + " " + title + " " + publishDate;
	}
}
