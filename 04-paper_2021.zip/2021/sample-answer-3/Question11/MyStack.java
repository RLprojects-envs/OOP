package Question11;

import java.util.LinkedList;

public class MyStack {
	private LinkedList<String> lst;

	MyStack() {
		lst = new LinkedList<>();
	}

public void push(String x){
	lst.push("x"); 
}

public String pop(){
	String s = lst.pop();
	return s;
}

public String peek(){
	return lst.peek();
}

public boolean search(String x){
	if (lst.contains(x))
        return true;

	else
		return false;
}

public int size(){
	return lst.size();
}
}
