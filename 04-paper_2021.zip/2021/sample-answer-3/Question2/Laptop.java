package Question2;

/*
a) An interface is like an "empty shell", just using by calling the methods from other classes. In another hand,
   abstract classes are classes, and in it you can define a behavior for them.
 */

class Battery {
	private String type;
	private int voltage;

	public Battery(String type, int voltage) {
		this.type = type;
		this.voltage = voltage;
	}

	public String getType() {
		return type;
	}

	public int getVoltage() {
		return voltage;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setVoltage(int voltage) {
		this.voltage = voltage;
	}
}

class Laptop {
	private Battery battery;
	private String brand;

	public Laptop(Battery battery, String brand) {
		this.battery = battery;
		this.brand = brand;
	}

	public Battery getBattery() {
		return battery;
	}

	public String getBrand() {
		return brand;
	}
}

