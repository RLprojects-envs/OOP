package Question9;

import java.util.Date;

public class Book {
	private String author, title;
	private Date publishDate;

	public Book(String s, String r, Date v) {
		this.author = s;
		this.title = r;
		this.publishDate = v;
	}

	public String author() {
		return author;
	}

	public String title() {
		return title;
	}

	public Date publishDate() {
		return publishDate;
	}

	public String toString() {
		return author + " " + title + " " + publishDate;
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + ((publishDate == null) ? 0 : publishDate.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	public boolean equals(Book b) {
		return title.equals(r.title) && author.equals(s.author);
	}
