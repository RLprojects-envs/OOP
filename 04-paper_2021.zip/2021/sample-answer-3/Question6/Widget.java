package Question6;

/*
a) A static variable mean that in the class it has been defiened, the value can not changed after it has been defiened.
   An instance variable is a non-static variable, you need to create it and use it inside objects created in the class.
   
   Exemple of static variable :
   
   class StaticVariable {
      static int val() {
          return 1;
      }
   } 
   
   Exemple of instance variable :
   
   class InstanceVariable {
   
   	  int val = 1;
   	  
      public static void main(String[] args) {
          InstanceVariable i = new InstanceVariable();
          System.out.print(i.val);
      }
   } 
   
 */

public class Widget {
	static int numberOfWidgets() {
        return 1;
    }
	
	public static void main(String[] args) {
		Widget widget = new Widget();
	}
}
