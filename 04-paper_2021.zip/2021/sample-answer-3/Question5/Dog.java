package Question5;

/* 
a) In java when you create a String object, it is automaticelly immutable.
   In fact by changing the value of this String, java is going to create a new String object.
   
 b) By making classes immutable, you fix the value of the variables and all the data inside it. 
    Which means you avoid a lot of problems if you work with different classes linked together and
    need to share informations between them.
 */

public class Dog {
	private String breed;
	private String name;
	private int age;

	public Dog(String b, String n, int a) {
		breed = b;
		name = n;
		age = a;
	}

	public String breed() {
		return breed;
	}

	public String name() {
		return name;
	}

	public int age() {
		return age;
	}
}

