package Question7;

/*
a) We call a singleton class a class that can have only one instance at a time.
   This type of class declares the static method "getInstance" which is returning the same instance of its own class.
   
 */

class Register {
	private static Register reg = null;
	private String[] data;
	private int size;

	private Register() {
		data[0] = "Initialize";	
		size = 12;
	}

	public static Register getRegister() {
		if (reg == null) {
            reg = new Register();
        }
        return reg;
    }

	public boolean register(String name) {
		if (name != "")
	    {
			return true;
	    }
		else {
			return  false;
		}
	}

	public int size() {
		return size;
	}

	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	private boolean search(String n) {
		boolean found = false;
		for (int j = 0; j < size && !found; j++)
			if (data[j].equals(n))
				found = true;
		return found;
	}
}
