package Question1;

public class Student {
	public String name;
	public static String[] listOfModules;
	public String address;
	public String id;
	
	public Student(String name, String[] listOfModules, String address, String id) {
		this.name = name;
		this.listOfModules = listOfModules;
		this.address = address;
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public String[] getListOfModules() {
		return listOfModules;
	}

	public String getAddress() {
		return address;
	}

	public String getId() {
		return id;
	}
	
	public String toString() {
		return "Student : [name=" + name + ", address=" + address + ", id=" + id + "]";
	}

	public static void main(String Args[]) {
		Student student = new Student("Theo", listOfModules, "10 Wellington Road, Cork, Irelan", "3079006
		" );
		System.out.println(student.getName());
		System.out.println(student.getId());
	}
	
}




