package question10;

import java.util.HashSet;

class Kennel {
	private HashSet<Dog> data = new HashSet<>();

	public void add(Dog s) {
		data.add(s);
	}

	public boolean search(Dog s) {// search for Dog s} (2 marks)
		for (Dog temp : data) {
			if (temp.equals(s))
				return true;
		}
		return false;
	}

	public Dog get(String num) {
		for (Dog temp : data) {
			if (temp.id().equals(num))
				return temp;
		}
		return null;
		// return reference to Dog that has id equal to num
	}

	public boolean replace(Dog s1, Dog s2) {
		if (search(s1)) {
			data.remove(s1);
			data.add(s2);
			return true;
		} else {
			return false;
		}
		// remove the Dog who is equal to s1 and replace them with Dog s2
//return false if student s1 is not in set, true otherwise
	}

	public void addDogs(HashSet<Dog> set) {
//add the collection of Dogs to data
	}
}