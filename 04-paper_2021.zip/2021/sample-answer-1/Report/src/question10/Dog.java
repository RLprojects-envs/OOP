package question10;

import java.util.Objects;

public class Dog {
	private String id, name, breed;

	public Dog(String i, String n, String c) {
		id = i;
		name = n;
		breed = c;
	}

	public String id() {
		return id;
	}

	public String name() {
		return name;
	}

	public String breed() {
		return breed;
	}

	public String toString() {
		return id + " " + name + " " + breed;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dog other = (Dog) obj;
		return Objects.equals(id, other.id);
	}

}