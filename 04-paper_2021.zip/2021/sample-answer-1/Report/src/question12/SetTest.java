package question12;

import java.util.Arrays;
import java.util.TreeSet;

class SetTest {
	TreeSet<Integer> ts1 = new TreeSet<>(Arrays.asList(1, 3, 5, 7, 9));
	TreeSet<Integer> ts2 = new TreeSet<>(Arrays.asList(2, 3, 4, 5));

public void testIntersection(){
	ts1.retainAll(ts2);
}

public void testDifference(){ 
	ts1.removeAll(ts2);
}

@Override
public String toString() {
	return "SetTest [ts1=" + ts1 + ", ts2=" + ts2 + "]";
}
}