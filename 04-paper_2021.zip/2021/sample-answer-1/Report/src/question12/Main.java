package question12;

public class Main {

	public static void main(String[] args) {
		
		SetTest setTest = new SetTest();
		setTest.testDifference();
		System.out.println(setTest);
		setTest.testIntersection();
		System.out.println(setTest);
		
	}

}
