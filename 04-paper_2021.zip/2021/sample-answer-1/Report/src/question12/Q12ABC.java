package question12;

public class Q12ABC {
	

	//Wrapper classes are Double, Integer, Character
	
	//An arrayList is a class
	//List is an interface
	
	//
	
	public Q12ABC() {
		// TODO Auto-generated constructor stub
	}

}
