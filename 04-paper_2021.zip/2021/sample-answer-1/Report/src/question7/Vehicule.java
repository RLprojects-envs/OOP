package question7;

public class Vehicule {
	private String vin;

	public Vehicule(String v) {
		vin = v;
	}

	public String getVin() {
		return vin;
	}

	public String toString() {
		return vin;
	}

	public String manufactureDate() {
		return vin;
	}
}
