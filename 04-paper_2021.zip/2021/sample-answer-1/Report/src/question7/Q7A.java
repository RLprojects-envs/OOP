package question7;

//It means that all classes in java are extending from the Object class

//The toString and equals functions are inherited from the object class. The benefit is that we can already call them in the inheritated class.

public class Q7A {

}
