package question7;

public class Car extends Vehicule {

	private String body;
	private double milesPerGalon;

	public Car(String v, String body, double milesPerGalon) {
		super(v);
		this.body = body;
		this.milesPerGalon = milesPerGalon;
	}

	// The advantages of extending is that some class are already available for the
	// Car class and we can use the concept of polymorphism

	@Override
	public String toString() {
		return "Car [body=" + body + ", milesPerGalon=" + milesPerGalon + "]";
	}
	

}
