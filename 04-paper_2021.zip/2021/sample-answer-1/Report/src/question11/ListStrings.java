package question11;

import java.util.ArrayList;
import java.util.List;

public class ListStrings {
	private ArrayList<String> lst;

	ListStrings() {
		lst = new ArrayList<>();
	}

	public void addEnd(String x) {// append x at end of list lst} (2 marks)
		lst.add(x);
	}

	public void addHead(String x) {// add x at head of list lst} (2 marks)
		lst.add(0, x);
	}

	public void add(List<String> dt) {// append list dt to lst} (2 marks)
		lst.addAll(dt);
	}

	public int freq(String x) {
		int freq = 0;
		for (String temp : lst) {
			if (temp.equalsIgnoreCase(x)) {
				freq++;
			}
		}
		return freq;
	}
}