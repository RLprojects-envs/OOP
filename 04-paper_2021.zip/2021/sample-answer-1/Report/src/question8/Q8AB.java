package question8;

public final class Q8AB {

	public enum Level {
	    HIGH,
	    MEDIUM,
	    LOW
	}
	
	/*
	 * Final can be used for : - variable that cannot be modified - methods that
	 * cannot be override - class that cannot be inherited
	 */

	/*
	 * enum Level is a type we create with only several possibilities like the Level
	 */
	
	private final String name;

	public Q8AB(String n) {
		name = n;
	}

	public final String getName() {
		return name;
	}

}
