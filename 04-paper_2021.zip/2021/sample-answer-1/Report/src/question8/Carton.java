package question8;

public class Carton implements Comparable<Carton> {
	private String material;
	private int size;

	public Carton(String m, int s) {
		material = m;
		size = s;
	}

	public String material() {
		return material;
	}

	public int size() {
		return size;
	}

	public void setMaterial(String m) {
		material = m;
	}

	public void setSize(int s) {
		size = s;
	}

	public String toString() {
		return material + " - " + size;
	}

	@Override
	public int compareTo(Carton o) {
		return this.material.compareTo(o.material);
//		int result = this.material.compareTo(o.material);
//
//		if (result == 0) {
//			if (this.size == o.size)
//				return 0;
//			else if (this.size > o.size)
//				return 1;
//			else
//				return -1;
//		} else if (result == 1) {
//			return result;
//		} else {
//			return result;
//		}
	}
}