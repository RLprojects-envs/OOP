package question1;

public class BankCustomerTest {

	public static void main(String[] args) {
		
		String[] quentinAccountsNumber = {"122343123","zaeza�&"};
		BankCustomer quentin  = new BankCustomer("Quentin Morel", quentinAccountsNumber, "France, Paris", "0782717622");
		
		System.out.println(quentin);

	}

}
