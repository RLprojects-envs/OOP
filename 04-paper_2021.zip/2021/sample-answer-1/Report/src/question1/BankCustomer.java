package question1;

import java.util.Arrays;

public class BankCustomer {

	private String name;
	private String[] accountNumbers;
	private String address;
	private String phone;

	public BankCustomer(String name, String[] accountNumbers, String address, String phone) {
		super();
		this.name = name;
		this.accountNumbers = accountNumbers;
		this.address = address;
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public String[] getAccountNumbers() {
		return accountNumbers;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}

	@Override
	public String toString() {
		return "BankCustomer [name=" + name + ", accountNumbers=" + Arrays.toString(accountNumbers) + ", address="
				+ address + ", phone=" + phone + "]";
	}

}
