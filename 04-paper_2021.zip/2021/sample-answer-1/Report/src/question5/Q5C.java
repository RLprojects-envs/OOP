package question5;

//Singleton class are class that allow only one instance of the class
//used when only a instance of the class is required

class Q5C {
	//The error comes from the fact that a static function cannot access an non-static attribute
	//To access it we can proceed like below
	
	private static Q5C singleInstance= null;
	private int num2;

	private Q5C(int n) {
		num2 = n;
	}

	public static void modNum2(int n) {
		if (singleInstance==null)
			singleInstance= new Q5C(n);
	}
	
	public Q5C getInstance()
	{
		return singleInstance;
	}
}
