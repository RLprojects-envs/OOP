package question5;

public class Answers {

	/*
	 * Static methods are methods that belongs to the class and not to the objects.
	 * It means an object cannot call them, we can call them only by writing the name of the class and the name of the function like:
	 * Class.method();
	 */
}
