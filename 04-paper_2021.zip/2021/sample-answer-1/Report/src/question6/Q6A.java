package question6;

//An immutable class is a class that once instantiate cannot be modified. To modify it, you need to re-instantiate it.
//Another example of immutable class is Double

public class Q6A {

}
