package question6;

//Flag is mutable because there is setter functions and attributes are public.
//There is no encapsulation because attributes are public

public final class Flag {
	private final String nation, mainColour;

	public Flag(String nation, String mainColour) {
		this.nation = nation;
		this.mainColour = mainColour;
	}

	public String getNation() {
		return nation;
	}

	public String getMainColour() {
		return mainColour;
	}
}