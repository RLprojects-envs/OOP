package question3;

class Circle {
	private Point centre;
	private double radius;

	public Circle(Point c, double r) {
		centre = c;
		radius = r;
	}

	public Point centre() {
		return centre;
	}

	public double radius() {
		return radius;
	}

	public String toString() {
		return "Centre: " + centre.toString() + " radius: " + radius;
	}
}