package question3;

class Point {
	private int x, y;

	public Point(int x1, int y1) {
		x = x1;
		y = y1;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void setX(int x1) {
		x = x1;
	}

	public void setY(int y1) {
		y = y1;
	}

	public String toString() {
		return "Point (" + x + "," + y + ")";
	}
}