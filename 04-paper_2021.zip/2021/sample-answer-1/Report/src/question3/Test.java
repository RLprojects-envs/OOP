package question3;

public class Test {

	public static void main(String[] args) {
		Point p = new Point(1, 4);
		Circle c = new Circle(p, 5.0);

//		Point p = new Point(1.0,4.0);
//		Circle c = new Circle(new Point(p.getX, p.getY),5.0)
		
		System.out.println(p);
		System.out.println(c);
		
		
	}

}
