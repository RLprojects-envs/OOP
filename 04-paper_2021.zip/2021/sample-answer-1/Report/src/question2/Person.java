package question2;

public class Person {

	//Data are hidden because they are private and you can access them only with functions.
	private String name;
	private String lastName;

	public Person(String name, String lastName) {
		super();
		this.name = name;
		this.lastName = lastName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", lastName=" + lastName + "]";
	}
	
	
}
