package question2;

class Book {

	private String title;
	private int publishYear;

	public Book(String title, int publishYear) {
		this.title = title;
		this.publishYear = publishYear;
	}

	public Book(Book b) {
		this.title = b.title;
		this.publishYear = b.publishYear;
	}

	public String getTitle() {
		return title;
	}

	public int getPublishYear() {
		return publishYear;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setPublishYear(int publishYear) {
		this.publishYear = publishYear;
	}
}
