package question2;

class libraryBook {
	private Book book;
	private String catalogue;

	public libraryBook(Book book, String catalogue) {
		this.book = new Book(book);
		this.catalogue = catalogue;
	}

	public Book getBook() {
		return book;
	}

	public String getCatalogue() {
		return catalogue;
	}

}