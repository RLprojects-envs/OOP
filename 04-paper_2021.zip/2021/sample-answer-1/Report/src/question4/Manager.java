package question4;

public class Manager extends Employee {

	private String id;
	private String office;

	public Manager(String name, String address, String ppsn, String id, String office) {
		super(name, address, ppsn);
		id = this.id;
		office = this.office;
	}

	@Override
	public String toString() {
		return "Manager [getName()=" + getName() + ", getAddress()=" + getAddress() + ", getPpsn()=" + getPpsn()
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}
}
