package question4;

//Question a)
// In the case of inheritance, if we want a function inherited to be different from the mother class.
// We need to override it, than a function toString from a vehicule will display "this is a vehicule" and a class car 
// that inherited from it, we can override the toString function to display "this is a car".


class Employee {
	private String name;
	private String address;
	private String ppsn;

	public Employee(String name, String address, String ppsn) {
		this.name = name;
		this.address = address;
		this.ppsn = ppsn;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPpsn() {
		return ppsn;
	}

	public String toString() {
		return name + " " + address;
	}

}