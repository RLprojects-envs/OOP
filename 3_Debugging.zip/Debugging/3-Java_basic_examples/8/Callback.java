/**
 * L09 L04
 */
public interface Callback {

    void callback(int param);
}