/**
 * C09 L12
 * 
 * Use the default method.
 */
public class DefaultMethodDemo {

    public static void main(String[] args) {
        MyIFImp obj = new MyIFImp();

        System.out.println(obj.getNumber());

        System.out.println(obj.getString());
    }
}