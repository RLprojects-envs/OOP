/**
 * C09 L02
 * 
 * Demo package p2.
 */
package p2;

public class Demo {

    public static void main(String[] args) {
        Protection2 ob1 = new Protection2();
        OtherPackage pb2 = new OtherPackage();
    }
}