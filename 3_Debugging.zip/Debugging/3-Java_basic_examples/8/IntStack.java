/**
 * C09 L07
 * 
 * Define an integer stack interface.
 */
public interface IntStack {

    void push(int item);

    int pop();
}