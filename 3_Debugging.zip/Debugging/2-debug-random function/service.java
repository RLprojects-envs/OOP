

class service{
    int price_per_kg;
    int delivery_time;
    int provider_max;
    int provider_min;
    int capacity;

    
    
    
    public service(int price_per_kg, int delivery_time, int provider_max, int provider_min, int capacity){
        this.price_per_kg = price_per_kg;
        this.delivery_time = delivery_time;
        this.provider_max = provider_max;
        this.provider_min = provider_min;
        this.capacity = capacity;
    }
    
    public int getPrice_per_kg() {
        return price_per_kg;
    }
    public void setPrice_per_kg(int price_per_kg) {
        this.price_per_kg = price_per_kg;
    }
    public int getDelivery_time() {
        return delivery_time;
    }
    public void setDelivery_time(int delivery_time) {
        this.delivery_time = delivery_time;
    }
    public int getProvider_max() {
        return provider_max;
    }
    public void setProvider_max(int provider_max) {
        this.provider_max = provider_max;
    }
    public int getProvider_min() {
        return provider_min;
    }
    public void setProvider_min(int provider_min) {
        this.provider_min = provider_min;
    }
    public int getCapacity() {
        return capacity;
    }
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
}