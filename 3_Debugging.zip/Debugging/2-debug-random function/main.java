
public class main {
    public static void main(String[] args) {
        
        int num_packets = 10;
        packets[] packet = new packets[num_packets];
        for (int i = 0; i < num_packets; i++) {
            int weight = (int) (Math.random() * 10);
            int budget = (int) (Math.random() * 10);
            int penalty_late = (int) (Math.random() * 10);
            int unmatched = (int) (Math.random() * 10);
            int timetodeadline = (int) (Math.random() * 10);
            int notificationtime = (int) (Math.random() * 10);
            packet[i] = new packets(weight, budget, penalty_late, unmatched, timetodeadline, notificationtime);
        }
        
        for (int i = 0; i < num_packets; i++) {
            System.out.println("Packet " + i + ":");
            System.out.println("Weight: " + packet[i].getWeight());
            System.out.println("Budget: " + packet[i].getBudget());
            System.out.println("Penalty_late: " + packet[i].getPenalty_late());
            System.out.println("Unmatched: " + packet[i].getUnmatched());
            System.out.println("Timetodeadline: " + packet[i].getTimetodeadline());
            System.out.println("Notificationtime: " + packet[i].getNotificationtime());
            System.out.println();
        }

        int num_service = 10;
        service[] service = new service[num_service];
        for (int i = 0; i < num_service; i++) {
            int price_per_kg = (int) (Math.random() * 10);
            int delivery_time = (int) (Math.random() * 10);
            int provider_max = (int) (Math.random() * 10);
            int provider_min = (int) (Math.random() * 10);
            int capacity = (int) (Math.random() * 10);
            service[i] = new service(price_per_kg, delivery_time, provider_max, provider_min, capacity);
        }
  
        for (int i = 0; i < num_service; i++) {
            System.out.println("Service " + i + ":");
            System.out.println("Price_per_kg: " + service[i].getPrice_per_kg());
            System.out.println("Delivery_time: " + service[i].getDelivery_time());
            System.out.println("Provider_max: " + service[i].getProvider_max());
            System.out.println("Provider_min: " + service[i].getProvider_min());
            System.out.println("Capacity: " + service[i].getCapacity());
            System.out.println();
        }

        
    }

    public static class sort {
        public static void sort(packets[] packet) {
            for (int i = 0; i < packet.length; i++) {
                for (int j = i + 1; j < packet.length; j++) {
                    if (packet[i].getWeight() > packet[j].getWeight()) {
                        packets temp = packet[i];
                        packet[i] = packet[j];
                        packet[j] = temp;
                    }
                }
            }
        }
    }

    
    public static class sort2 {
        public static void sort(service[] service) {
            for (int i = 0; i < service.length; i++) {
                for (int j = i + 1; j < service.length; j++) {
                    if (service[i].getPrice_per_kg() > service[j].getPrice_per_kg()) {
                        service temp = service[i];
                        service[i] = service[j];
                        service[j] = temp;
                    }
                }
            }
        }
    }
    

}

