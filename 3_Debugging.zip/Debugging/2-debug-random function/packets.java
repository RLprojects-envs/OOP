

class packets{
    int weight;
    int budget;
    int penalty_late;
    int unmatched;
    int timetodeadline;
    int notificationtime;
    
    public packets(int weight, int budget, int penalty_late, int unmatched, int timetodeadline, int notificationtime){
        this.weight = weight;
        this.budget = budget;
        this.penalty_late = penalty_late;
        this.unmatched = unmatched;
        this.timetodeadline = timetodeadline;
        this.notificationtime = notificationtime;
    }
    
    public int getWeight() {
        return weight;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }
    public int getBudget() {
        return budget;
    }
    public void setBudget(int budget) {
        this.budget = budget;
    }
    public int getPenalty_late() {
        return penalty_late;
    }
    public void setPenalty_late(int penalty_late) {
        this.penalty_late = penalty_late;
    }
    public int getUnmatched() {
        return unmatched;
    }
    public void setUnmatched(int unmatched) {
        this.unmatched = unmatched;
    }
    public int getTimetodeadline() {
        return timetodeadline;
    }
    public void setTimetodeadline(int timetodeadline) {
        this.timetodeadline = timetodeadline;
    }
    public int getNotificationtime() {
        return notificationtime;
    }
    public void setNotificationtime(int notificationtime) {
        this.notificationtime = notificationtime;
    }
}